# DEPLOYMENT GUIDE #

## Prerequisites

-  node v0.12.1
-  mongodb

## Install

run `npm install`.

## Database

run `node test_files/initDB` to add sample data.

## Configure

Open config/config.js and change the configuration as needed:

-  MONGODB_URL: The connection url
-  MONGODB_CONNECTION_POOL_SIZE: The connection poll size
-  WEB_SERVER_PORT: The web server port
-  SALT_WORK_FACTOR: The salt work factor
-  SESSION_TOKEN_DURATION: The session token duration
-  JWT_SECRET: The jwt secret
-  ROUTES: The api routes
-  SITE_ADMIN_EMAIL: The site admin email
-  SMTP_HOST: The smtp host
-  SMTP_PORT: The smtp port
-  SMTP_USERNAME: The smtp username
-  SMTP_PASSWORD: The smtp password
-  OFFSET: The default offset
-  LIMIT: The default limit
-  ALERT_STATUSES: The valid alert statuses
-  USER_COMFORT_LEVELS: The valid user comfort levels
-  ROLES: The valid roles
-  ROOM_SIZES: The valid room sizes

## Run the server

Execute `npm start` or `node app`.

## Verify

Use postman to verify. See Verification.doc for details.

