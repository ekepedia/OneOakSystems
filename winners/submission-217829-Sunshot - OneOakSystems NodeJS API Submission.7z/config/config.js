/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents the configuration file.
 * 
 * @author TCSCODER
 * @version 1.0
 */
"use strict";

module.exports = {

    MONGODB_URL : "mongodb://localhost:27017/oneoaksystems",

    MONGODB_CONNECTION_POOL_SIZE : 50,

    WEB_SERVER_PORT : 3000,

    SALT_WORK_FACTOR : 1,

    SESSION_TOKEN_DURATION : 50000000,

    JWT_SECRET : "jwtsecret",

    ROUTES : {
        'POST /api/signup' : 'UserController#signUp',
        'POST /api/signin' : 'UserController#signIn',
        'GET /api/me' : 'UserController#getMe',
        'GET /api/houses' : 'HouseController#getHouses',
        'GET /api/house/:id' : 'HouseController#getHouse',
        'GET /api/house/:id/stats' : 'HouseController#getStatus',
        'POST /api/rooms' : 'RoomController#setRoom',
        'GET /api/rooms/:id' : 'RoomController#getRoom',
        'GET /api/alerts' : 'RoomController#getAlerts',
        'POST /api/room/:id/temperature' : 'RoomController#setRoomTemperature',
        'GET /api/room/:id/temperature' : 'RoomController#getRoomTemperature',
        'GET /api/room/plot' : 'RoomController#getRoomTemperaturePlotData',
        'POST /api/schedules' : 'RoomController#setRoomSchedule',
        'GET /api/schedules' : 'RoomController#getRoomSchedule',
        'POST /api/users' : 'HouseController#setHouseUser',
        'GET /api/users/:id' : 'UserController#getUser',
        'GET /api/houses/:id/users' : 'HouseController#getHouseUsers',
        'GET /api/users' : 'UserController#getUsers',
        'DELETE /api/house/:id/users/:userId' : 'HouseController#removeHouseUser',
        'GET /api/houses/:id/calculate' : 'HouseController#calculateSavings'
    },

    SITE_ADMIN_EMAIL : "admin@mail.com",
    SMTP_HOST : "localhost",
    SMTP_PORT : 25000,
    SMTP_USERNAME : "user1",
    SMTP_PASSWORD : "123456",

    OFFSET : 0,
    LIMIT : 10,

    ALERT_STATUSES : [ 'current', 'resolved' ],

    USER_COMFORT_LEVELS : [ 'cold', 'cool', 'perfect', 'warm', 'hot', 'custom' ],

    ROLES : [ 'admin', 'operator', 'user', 'viewer' ],

    ROOM_SIZES : [ 'very small', 'small', 'medium', 'large', 'very large' ]
};
