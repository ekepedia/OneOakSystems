/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This module contains helper functions.
 * 
 * @version 1.0
 * @author TCSCODER
 */
'use strict';

var config = require('../config/config'),
    _ = require('underscore'),
    helper = {},
    ValidationError = require('../errors/ValidationError');

/**
 * Checks if the value is null.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkNotNull = function(value, name) {
    if (!value) {
        throw new ValidationError(name + ' should not be null or empty.');
    }
};

/**
 * Checks if the alert status is valid.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkAlertStatus = function(value) {
    if (!value) {
        return;
    }
    if (config.ALERT_STATUSES.indexOf(value) == -1) {
        throw new ValidationError('alert status is invalid.');
    }
};

/**
 * Checks if the user comfort level is valid.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkUserComfortLevel = function(value) {
    helper.checkStringNotNullNotEmpty(value, 'userComfortLevel')
    if (config.USER_COMFORT_LEVELS.indexOf(value) == -1) {
        throw new ValidationError('user comfort level is invalid.');
    }
};

/**
 * Checks if the role is valid.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkRole = function(value) {
    helper.checkStringNotNullNotEmpty(value, 'role')
    if (config.ROLES.indexOf(value) == -1) {
        throw new ValidationError('role is invalid.');
    }
};

/**
 * Checks if the room size is valid.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkRoomSize = function(value) {
    helper.checkStringNotNullNotEmpty(value, 'size')
    if (config.ROOM_SIZES.indexOf(value) == -1) {
        throw new ValidationError('size is invalid.');
    }
};

/**
 * Checks if the string is null or empty.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkStringNotNullNotEmpty = function(value, name) {
    if (!value) {
        throw new ValidationError(name + ' should not be null or empty.');
    }
    if (!_.isString(value)) {
        throw new ValidationError(name + ' should be a string.');
    }
};

/**
 * Checks if the email is valid.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkEmail = function(value, name) {
    helper.checkStringNotNullNotEmpty(value, name);
    if (!/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/i
            .test(value)) {
        throw new ValidationError('email format should be correct.');
    }
};

/**
 * Checks if the value is positive number.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkPositiveNumber = function(value, name) {
    helper.checkNumber(value, name);
    value = parseInt(value);
    if (value < 0) {
        throw new ValidationError(name + ' should be a valid positive number.');
    }
};

/**
 * Checks if the value is null.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkArrayNotNullNotEmpty = function(value, name) {
    if (value == null || value == undefined) {
        throw new ValidationError(name + ' should not be null.');
    }
    if (!_.isArray(value)) {
        throw new ValidationError(name + ' should be an array.');
    }
    if (value.length == 0) {
        throw new ValidationError(name + ' should not be empty.');
    }
};

/**
 * Checks if the value is number.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkNumber = function(value, name) {
    if (value == null || value == undefined) {
        throw new ValidationError(name + ' should not be null.');
    }
    value = parseInt(value);
    if (!_.isNumber(value) || isNaN(value)) {
        throw new ValidationError(name + ' should be a valid number.');
    }
};

/**
 * Checks if the value is ObjectId.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkObjectId = function(value, name) {
    helper.checkStringNotNullNotEmpty(value, name);
    if (!/^[a-zA-Z0-9]{24}$/.test(value)) {
        throw new ValidationError(name + " should be a valid ObjectId (24 hex characters).");
    }
};

/**
 * Checks if the schdule is valid.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkSchedule = function(value, name) {
    helper.checkArrayNotNullNotEmpty(value, 'schedule');
    value.forEach(function(val) {
        var startTimeValue = helper.checkRangeValue(val.startTime, 'schedule.startTime');
        var endTimeValue = helper.checkRangeValue(val.endTime, 'schedule.endTime');
        if (endTimeValue <= startTimeValue) {
            throw new ValidationError('schedule.endTime must be larger than schedule.startTime.');
        }
        helper.checkPositiveNumber(val.value, 'schedule.value');
    });
};

/**
 * Checks if the range is valid.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkRangeValue = function(value, name) {
    helper.checkStringNotNullNotEmpty(value, name);
    var values = value.split(':');
    if (!_.isArray(values) || values.length != 2) {
        throw new ValidationError(name + " should be in correct format (00:00 to 23:59).");
    }
    if (values[0].length != 2) {
        throw new ValidationError(name + "'s hours should be in correct format (00 to 23).");
    }
    if (values[1].length != 2) {
        throw new ValidationError(name + "'s minutes should be in correct format (00 to 23).");
    }

    values[0] = parseInt(values[0]);
    if (!_.isNumber(values[0]) || isNaN(values[0])) {
        throw new ValidationError(name + "'s hours should be in correct format (00 to 23).");
    } else if (values[0] < 0 || values[0] > 23) {
        throw new ValidationError(name + "'s hours should be in correct format (00 to 23).");
    }
    values[1] = parseInt(values[1]);
    if (!_.isNumber(values[1]) || isNaN(values[1])) {
        throw new ValidationError(name + "'s minutes should be in correct format (00 to 59).");
    } else if (values[1] < 0 || values[1] > 59) {
        throw new ValidationError(name + "'s minutes should be in correct format (00 to 59).");
    }
    return value[0] * 60 + values[1];
};

/**
 * Checks if the value is in correct date format.
 * 
 * @param value
 *            {String} the value.
 * @param name
 *            {String} the name.
 * @throws {ValidationError}
 *             the error.
 */
helper.checkDate = function(value, name) {
    if (_.isString(value)) {
        var date = new Date(value);
        if (date == 'Invalid Date') {
            throw new ValidationError(name + ' should be in correct date format.');
        }
        if (!_.isDate(date)) {
            throw new ValidationError(name + ' should be in correct date format.');
        }
    } else {
        if (!_.isDate(value)) {
            throw new ValidationError(name + ' should be a valid Date.');
        }
    }
};

/**
 * Gets the timestamps base on start date and end date.
 * 
 * @param startDate
 *            {Date} the start date.
 * @param endDate
 *            {Date} the end date.
 */
helper.getTimestamps = function(startDate, endDate) {
    var duration = (endDate.getTime() - startDate.getTime()) / 1000 / 60 / 60 / 24;
    var timestamps = [];
    if (duration == 1) {
        for ( var i = 0; i < 25; i++) {
            timestamps.push(new Date(startDate.getTime() + 1000 * 60 * 60 * i));
        }
    } else if (duration > 1 && duration <= 3) {
        for ( var i = 0; i < 12; i++) {
            var timestamp = new Date(startDate.getTime() + 1000 * 60 * 60 * 6 * i);
            timestamps.push(timestamp);
            if (timestamp.getTime() > endDate.getTime()) {
                timestamps.push(timestamp);
                break;
            }
        }
    } else if (duration > 3 && duration <= 7) {
        for ( var i = 0; i < 14; i++) {
            var timestamp = new Date(startDate.getTime() + 1000 * 60 * 60 * 12 * i);
            timestamps.push(timestamp);
            if (timestamp.getTime() > endDate.getTime()) {
                timestamps.push(timestamp);
                break;
            }
        }
    } else if (duration > 7 && duration <= 30) {
        for ( var i = 0; i < 30; i++) {
            var timestamp = new Date(startDate.getTime() + 1000 * 60 * 60 * 24 * i);
            timestamps.push(timestamp);
            if (timestamp.getTime() > endDate.getTime()) {
                timestamps.push(timestamp);
                break;
            }
        }
    } else if (duration > 30) {
        for ( var i = 0; i < Number.MAX_VALUE; i++) {
            var timestamp = new Date(startDate.getTime() + 1000 * 60 * 60 * 24 * 7 * i);
            timestamps.push(timestamp);
            if (timestamp.getTime() > endDate.getTime()) {
                timestamps.push(timestamp);
                break;
            }
        }
    }
    return timestamps;
}

module.exports = helper;
