/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Mail Helper. This file is a wrapper for all methods that are related with emails.
 * 
 * @version 1.0
 * @author TCSCODER
 */
'use strict';

var config = require('../config/config'),
    fs = require('fs'),
    jade = require('jade'),
    path = require('path'),
    nodemailer = require('nodemailer'),
    smtpTransport = require('nodemailer-smtp-transport'),
    _emailTemplatesPath = path.join(__dirname, '../views/email_templates/');

/**
 * Get nodemailer transporter for sending emails.
 * 
 * @return {smtpTransport} an smtp transport object to send emails.
 */
function _getTransporter() {
    return nodemailer.createTransport(smtpTransport({
        host : config.SMTP_HOST,
        port : config.SMTP_PORT,
        auth : {
            user : config.SMTP_USERNAME,
            pass : config.SMTP_PASSWORD
        }
    }));
}

/**
 * Render email template from jade templates.
 * 
 * @param templateName
 *            {String} the jade template filename you want to render.
 * @param context
 *            {Object} the object that you want to interpolate to the template.
 * @param callback
 *            {Function} the callback function <error: Error, html: String>.
 */
exports.renderEmailTemplate = function(templateName, context, callback) {
    var filePath = path.join(_emailTemplatesPath, templateName + '.jade');
    fs.readFile(filePath, 'utf8', function(err, file) {
        if (err) {
            callback(err);
        } else {
            var compiledTemplate = jade.compile(file, {
                filename : filePath
            });
            var mailContext = context;
            var html = compiledTemplate(mailContext);
            callback(null, html);
        }
    });
};

/**
 * Send mail function.
 * 
 * @param from
 *            {String} the sender of the email.
 * @param to
 *            {String} the receiver of the email. It should be a valid email.
 * @param subject
 *            {String} the subject of the email.
 * @param html
 *            {String} the content of the email in html format.
 * @param callback
 *            {Function} the callback function <error: Error>.
 */
exports.sendMail = function(from, to, subject, html, callback) {
    var mailOptions = {
        from : from,
        to : to,
        subject : subject,
        html : html
    };
    var transporter = _getTransporter();
    transporter.sendMail(mailOptions, callback);
};
