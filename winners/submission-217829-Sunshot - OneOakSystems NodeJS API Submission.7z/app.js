/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * The main application file.
 * 
 * @version 1.0
 * @author TCSCODER
 */
'use strict';

var winston = require('winston'),
    express = require('express'),
    bodyParser = require('body-parser'),
    _ = require('underscore'),
    config = require('./config/config'),
    auth = require('./middleware/auth');

winston.remove(winston.transports.Console);
winston.add(winston.transports.Console, {
    level : 'debug',
    timestamp : true
});

var app = express();

app.use(bodyParser.json({
    limit : '50mb'
}));
app.use(bodyParser.urlencoded({
    limit : '50mb',
    extended : true
}));

var router = express.Router();
_.each(_.keys(config.ROUTES),
        function(route) {
            var action = config.ROUTES[route],
                httpMethod = route.split(/\s+/).shift().toLowerCase(),
                    url = route.split(/\s+/).pop(),
                    controllerName = action.split('#').shift(),
                    controllerMethod = action.split('#').pop(),
                    controller = require('./controllers/' + controllerName);
            if (url != '/api/signup' && url != '/api/signin') {
                router[httpMethod](url, auth(url), controller[controllerMethod]);
            } else {
                router[httpMethod](url, controller[controllerMethod]);
            }
        });

app.use(router);

app.listen(config.WEB_SERVER_PORT);
winston.info('Express server listening on port ' + config.WEB_SERVER_PORT);
