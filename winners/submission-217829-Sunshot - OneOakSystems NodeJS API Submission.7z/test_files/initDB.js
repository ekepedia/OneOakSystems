/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Initial DB for testing.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var COLLECTION_NAMES = [ 'User', 'House', 'HouseUser', 'HouseInfo', 'HouseStatus', 'Room', 'RoomSchedule',
        'RoomTemperature', 'RoomAlerts', 'SessionToken' ],
    _ = require('underscore'), dbModels = require('../models');

/**
 * Inital the Database.
 */
_.each(COLLECTION_NAMES, function(name) {
    dbModels[name].remove({}).exec(function(err, result) {
        console.log('DB Collection [' + name + '] is clear.');

        var Schema = dbModels[name];

        var data = require('./' + name + '.json');
        _.each(data, function(value) {
            new Schema(value).save(function(err) {
                if (err) {
                    console.log(err);
                }
            });
        });
        console.log('DB Collection [' + name + '] is initialised.');
    });
});

dbModels['RoomPlot'].remove({}).exec(function(err, result) {
    console.log('DB Collection [RoomPlot] is clear.');
    var now = new Date().getTime();
    for ( var i = 0; i < 45 * 48; i++) {
        var timestamp = new Date(now - 1000 * 60 * 30 * i);
        var roomPlot = {};
        roomPlot.roomId = '333333333333333333333333';
        roomPlot.year = timestamp.getYear();
        roomPlot.month = timestamp.getMonth();
        roomPlot.day = timestamp.getDay();
        roomPlot.hour = timestamp.getHours();
        roomPlot.minute = timestamp.getMinutes();
        roomPlot.second = timestamp.getSeconds();
        roomPlot.inDST = true;
        roomPlot.timestamp = timestamp;
        roomPlot.light = 1;
        roomPlot.tempAnalog = 2;
        roomPlot.IR = 3;
        roomPlot.tempDigital = 4;
        roomPlot.currentTemp = parseInt(Math.random() * 6) + 20;
        roomPlot.outsideTemp = parseInt(Math.random() * 10) + 2;
        roomPlot.desiredTemp = parseInt(Math.random() * 5) + 22;
        roomPlot.fastHumidity = 5;
        roomPlot.slowHumidity = 6;
        new dbModels['RoomPlot'](roomPlot).save(function(err, result) {
            if (err) {
                console.log(err);
            }
        });
        roomPlot.roomId = '333333333333333333333334';
        new dbModels['RoomPlot'](roomPlot).save(function(err, result) {
            if (err) {
                console.log(err);
            }
        });
        roomPlot.roomId = '333333333333333333333336';
        new dbModels['RoomPlot'](roomPlot).save(function(err, result) {
            if (err) {
                console.log(err);
            }
        });
    }
    console.log('DB Collection [RoomPlot] is initialised.');
});
