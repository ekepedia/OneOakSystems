/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service provides methods to manage house users.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var HouseUser = require('../models/index').HouseUser,
    async = require('async'),
    ForbiddenError = require('../errors/ForbiddenError'),
    NotFoundError = require('../errors/NotFoundError');

/**
 * Creates or updates a house user.
 * 
 * @param houseUser
 *            {Object} the house user.
 * @param userId
 *            {Object} the user id.
 * @param callback
 *            {Function<error:Error, houseUser:HouseUser>} the callback function.
 */
exports.createOrUpdate = function(houseUser, userId, callback) {
    async.waterfall([ function(cb) {
        HouseUser.findOne({
            houseId : houseUser.houseId,
            userId : houseUser.userId
        }, cb);
    }, function(existing, cb) {
        if (!existing) {
            HouseUser.create(houseUser, callback);
        } else {
            if (existing.role == 'admin' && existing.userId.equals(userId)) {
                cb(new ForbiddenError('A admin cannot change himself to a lower role.'))
            } else if (existing.role == 'admin' && houseUser.role != 'admin') {
                async.waterfall([ function(cb2) {
                    HouseUser.find({
                        houseId : houseUser.houseId
                    }, cb2);
                }, function(houseUsers, cb2) {
                    var adminExist = false;
                    houseUsers.forEach(function(item) {
                        if (item.role == 'admin' && item.userId != houseUser.userId) {
                            adminExist = true;
                        }
                    });
                    cb2(null, adminExist);
                }, function(adminExist, cb2) {
                    if (adminExist) {
                        existing.role = houseUser.role;
                        existing.save(cb2);
                    } else {
                        cb2(new ForbiddenError('A house need at least one admin.'));
                    }
                } ], function(err, result) {
                    if (err) {
                        cb(err);
                    } else {
                        cb(null, result, count);
                    }
                });
            } else {
                existing.role = houseUser.role;
                existing.save(cb);
            }
        }
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
};

/**
 * Gets all user ids.
 * 
 * @param houseId
 *            {String} the house id.
 * @param offset
 *            {String} the offset.
 * @param limit
 *            {String} the limit.
 * @param callback
 *            {Function<error:Error, houseUsers:[HouseUser], count:Number>} the callback function.
 */
exports.getUserIds = function(houseId, offset, limit, callback) {
    async.waterfall([ function(cb) {
        HouseUser.find({
            houseId : houseId
        }, {
            userId : 1
        }).count(cb);
    }, function(count, cb) {
        HouseUser.find({
            houseId : houseId
        }, {
            userId : 1
        }).limit(limit).skip(offset).exec(function(err, result) {
            if (err) {
                cb(err);
            } else {
                cb(null, result, count);
            }
        });
    } ], function(err, result, count) {
        if (err) {
            callback(err);
        } else {
            callback(null, result, count);
        }
    });
};

/**
 * Gets all house ids.
 * 
 * @param houseId
 *            {String} the house id.
 * @param offset
 *            {String} the offset.
 * @param limit
 *            {String} the limit.
 * @param callback
 *            {Function<error:Error, houseUsers:[HouseUser], count:Number>} the callback function.
 */
exports.getHouseIds = function(userId, offset, limit, callback) {
    async.waterfall([ function(cb) {
        HouseUser.find({
            userId : userId
        }, {
            houseId : 1
        }).count(cb);
    }, function(count, cb) {
        HouseUser.find({
            userId : userId
        }, {
            houseId : 1
        }).limit(limit).skip(offset).exec(function(err, result) {
            if (err) {
                cb(err);
            } else {
                cb(null, result, count);
            }
        });
    } ], function(err, result, count) {
        if (err) {
            callback(err);
        } else {
            callback(null, result, count);
        }
    });
};

/**
 * Gets a house.
 * 
 * @param houseId
 *            {String} the house id.
 * @param callback
 *            {Function<error:Error, houseUsers:[HouseUser]>} the callback function.
 */
exports.get = function(houseId, callback) {
    HouseUser.findOne({
        houseId : houseId
    }, callback);
};

/**
 * Gets a role.
 * 
 * @param houseId
 *            {String} the house id.
 * @param callback
 *            {Function<error:Error, houseUsers:[HouseUser]>} the callback function.
 */
exports.getRole = function(houseId, userId, callback) {
    HouseUser.findOne({
        houseId : houseId,
        userId : userId
    }, {
        role : 1
    }, function(err, result) {
        if (err) {
            callback(err);
        } else {
            if (result) {
                callback(null, result.role);
            } else {
                callback(null, null);
            }
        }
    });
};

/**
 * Deletes a house user.
 * 
 * @param houseId
 *            {String} the house id.
 * @param userId
 *            {String} the user id.
 * @param callback
 *            {Function<error:Error>} the callback function.
 */
exports.remove = function(houseId, userId, callback) {
    async.waterfall([ function(cb) {
        HouseUser.findOne({
            houseId : houseId,
            userId : userId
        }, cb);
    }, function(existing, cb) {
        if (!existing) {
            cb(new NotFoundError('No house user found.'))
        } else if (existing.role == 'admin') {
            async.waterfall([ function(cb2) {
                HouseUser.find({
                    houseId : houseId
                }, cb2);
            }, function(houseUsers, cb2) {
                var adminExist = false;
                houseUsers.forEach(function(item) {
                    if (item.role == 'admin' && item.userId != userId) {
                        adminExist = true;
                    }
                });
                cb2(null, adminExist);
            }, function(adminExist, cb2) {
                if (adminExist) {
                    existing.remove(cb);
                } else {
                    cb2(new ForbiddenError('A house need at least one admin.'));
                }
            } ], function(err, result) {
                if (err) {
                    cb(err);
                } else {
                    cb(null, result, count);
                }
            });
        } else {
            existing.remove(cb);
        }
    } ], function(err, result, count) {
        if (err) {
            callback(err);
        } else {
            callback(null, result, count);
        }
    });
};
