/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service provides methods to manage room plots.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var RoomPlot = require('../models/index').RoomPlot,
    async = require('async'),
    helper = require('../helpers/helper');

/**
 * Gets the plot data.
 * 
 * @param houseId
 *            {String} the house id.
 * @param callback
 *            {Function<error:Error, houseUsers:[HouseUser], count:Number>} the callback function.
 */
exports.get = function(roomIds, startDate, endDate, callback) {
    var timestamps = helper.getTimestamps(startDate, endDate);

    var i = 0;
    async.map(timestamps, function(timestamp, cb) {
        if (i < timestamps.length - 1) {
            RoomPlot.find({
                timestamp : {
                    $gte : timestamp,
                    $lt : timestamps[i + 1]
                },
                roomId : {
                    $in : roomIds
                }
            }, {
                currentTemp : 1,
                outsideTemp : 1,
                desiredTemp : 1,
                timestamp : 1
            }, function(err, result) {
                var currentTemps = 0;
                var outsideTemps = 0;
                var desiredTemps = 0;
                result.forEach(function(data) {
                    currentTemps += data.currentTemp;
                    outsideTemps += data.outsideTemp;
                    desiredTemps += data.desiredTemp;
                });
                var avgTempData = {};
                avgTempData.timestamp = timestamp;
                avgTempData.avgCurrentTemp = currentTemps / result.length;
                avgTempData.avgOutsideTemp = outsideTemps / result.length;
                avgTempData.avgDesiredTemp = desiredTemps / result.length;
                cb(err, avgTempData);
            });
        } else {
            cb(null, null);
        }
        i++;
    }, function(err, avgTempDatas) {
        var timestamps = [ 'timestamp' ];
        var avgCurrentTempData = [ 'current_temp' ];
        var avgOutsideTempData = [ 'outside_temp' ];
        var avgDesiredTempData = [ 'desired_temp' ];
        avgTempDatas.forEach(function(avgTempData) {
            if (avgTempData) {
                timestamps.push(avgTempData.timestamp);
                avgCurrentTempData.push(avgTempData.avgCurrentTemp);
                avgOutsideTempData.push(avgTempData.avgOutsideTemp);
                avgDesiredTempData.push(avgTempData.avgDesiredTemp);
            }
        })
        if (err) {
            callback(err);
        } else {
            callback(null, timestamps, avgCurrentTempData, avgOutsideTempData, avgDesiredTempData);
        }
    });
};
