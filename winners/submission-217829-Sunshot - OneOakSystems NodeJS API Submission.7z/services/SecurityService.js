/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service exports application security functionality.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var User = require("../models/index").User,
    SessionToken = require("../models/index").SessionToken,
    bcrypt = require('bcrypt-nodejs'),
    jwt = require('jwt-simple'),
    async = require('async'),
    config = require("../config/config"),
    ForbiddenError = require('../errors/ForbiddenError'),
    NotFoundError = require('../errors/NotFoundError');

/**
 * Implements the email/password authentication.
 * 
 * @param email
 *            {String} the email.
 * @param password
 *            {String} the password.
 * @param callback
 *            {Function<error:Error, user:User>} the callback function.
 */
exports.authenticate = function(email, password, callback) {
    async.waterfall([ function(cb) {
        User.findOne({
            email : email
        }, cb);
    }, function(user, cb) {
        if (user) {
            bcrypt.compare(password, user.password, function(err, result) {
                if (err) {
                    cb(err);
                } else if (result) {
                    cb(null, user);
                } else {
                    cb(new ForbiddenError('user is not authenticated'));
                }
            });
        } else {
            cb(new NotFoundError('User not found'));
        }
    } ], callback);
};

/**
 * Authenticate the user based on the bearer session token.
 * 
 * @param token
 *            {String} the session access token.
 * @param callback
 *            {Function<error:Error, user:User, expirationDate:Date>} the callback function.
 */
exports.authenticateWithSessionToken = function(token, callback) {
    var expirationDate;
    async.waterfall([ function(cb) {
        SessionToken.findOne({
            token : token
        }, cb);
    }, function(sessionToken, cb) {
        if (!sessionToken) {
            return cb(new ForbiddenError('Session Token not found'));
        }
        var decoded = jwt.decode(sessionToken.token, config.JWT_SECRET);
        if (decoded.expiration > Date.now()) {
            User.findOne({
                _id : sessionToken.userId
            }, function(err, user) {
                expirationDate = decoded.expiration;
                cb(err, user);
            });
        } else {
            cb(new ForbiddenError('Session Token Expired'));
        }
    } ], function(err, user) {
        callback(err, user, expirationDate);
    });
};

/**
 * Generate the session token to be returned to client in case of login request.
 * 
 * @param userId
 *            {String} the user id.
 * @param callback
 *            {Function<error:Error, token:String>} the callback function.
 */
exports.generateSessionToken = function(userId, callback) {
    var dateObj = new Date();
    var millis = dateObj.getTime() + config.SESSION_TOKEN_DURATION;
    var token = jwt.encode({
        expiration : millis
    }, config.JWT_SECRET);
    SessionToken.create({
        userId : userId,
        token : token,
        expirationDate : millis
    }, function(err, sessionToken) {
        if (err) {
            callback(err);
        } else {
            callback(null, sessionToken.token);
        }
    });
};

/**
 * Generate a hash of the given plainText string.
 * 
 * @param plainText
 *            {String} the plainText string.
 * @param callback
 *            {Function<error:Error, user:User, hash:String>} the callback function.
 */
exports.generateHash = function(plainText, callback) {
    async.waterfall([ function(cb) {
        bcrypt.genSalt(config.SALT_WORK_FACTOR, cb);
    }, function(salt, cb) {
        bcrypt.hash(plainText, salt, null, cb);
    } ], callback);
};
