/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service provides methods to manage room schedules.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var RoomSchedule = require('../models/index').RoomSchedule;

/**
 * Creates a room schedule.
 * 
 * @param roomId
 *            {String} the room id.
 * @param roomSchedules
 *            {String} the room schedules.
 * @param callback
 *            {Function<error:Error, roomSchedule:RoomSchedule>} the callback function.
 */
exports.create = function(roomId, roomSchedules, callback) {
    var roomSchedule = {
        roomId : roomId,
        items : roomSchedules
    };
    RoomSchedule.create(roomSchedule, callback);
};

/**
 * Gets room schedules by room id.
 * 
 * @param roomId
 *            {String} the room id.
 * @param callback
 *            {Function<error:Error, roomSchedules:[RoomSchedule]>} the callback function.
 */
exports.getByRoom = function(roomId, callback) {
    RoomSchedule.find({
        roomId : roomId
    }, callback);
};

/**
 * Gets the latest room schedule by room id.
 * 
 * @param roomId
 *            {String} the room id.
 * @param callback
 *            {Function<error:Error, roomSchedule:RoomSchedule>} the callback function.
 */
exports.getLatestByRoom = function(roomId, callback) {
    RoomSchedule.find({
        roomId : roomId
    }).sort({
        "createDate" : "desc"
    }).exec(function(err, result) {
        if (err) {
            callback(err);
        } else if (result.length > 0) {
            callback(null, result[0]);
        } else {
            callback(null, null);
        }
    });
};
