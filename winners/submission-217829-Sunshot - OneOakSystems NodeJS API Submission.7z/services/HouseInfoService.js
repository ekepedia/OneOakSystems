/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service provides methods to manage house infomation.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var HouseInfo = require('../models/index').HouseInfo;

/**
 * Gets a house infomation.
 * 
 * @param houseId
 *            {String} the house id.
 * @param callback
 *            {Function<error:Error, houseInfo:HouseInfo>} the callback function.
 */
exports.get = function(houseId, callback) {
    HouseInfo.findOne({
        houseId : houseId
    }, callback);
};
