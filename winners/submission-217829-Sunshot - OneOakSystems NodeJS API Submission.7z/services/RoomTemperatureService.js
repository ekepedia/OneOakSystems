/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service provides methods to manage room temperature.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var RoomTemperature = require('../models/index').RoomTemperature;

/**
 * Gets room temperatures by room id.
 * 
 * @param roomId
 *            {String} the room id.
 * @param callback
 *            {Function<error:Error, roomTemperatures:[RoomTemperature]>} the callback function.
 */
exports.getByRoom = function(roomId, callback) {
    RoomTemperature.find({
        roomId : roomId
    }, callback);
};

/**
 * Gets the latest room temperature by room id.
 * 
 * @param roomId
 *            {String} the room id.
 * @param callback
 *            {Function<error:Error, roomTemperature:RoomTemperature>} the callback function.
 */
exports.getLatestByRoom = function(roomId, callback) {
    RoomTemperature.find({
        roomId : roomId
    }).sort({
        "createDate" : "desc"
    }).exec(function(err, result) {
        if (err) {
            callback(err);
        } else if (result.length > 0) {
            callback(null, result[0]);
        } else {
            callback(null, null);
        }
    });
};

/**
 * Creates a room temperature.
 * 
 * @param roomTemperature
 *            {RoomTemperature} the room temperature.
 * @param callback
 *            {Function<error:Error, roomTemperature:RoomTemperature>} the callback function.
 */
exports.create = function(roomTemperature, callback) {
    RoomTemperature.create(roomTemperature, callback);
};
