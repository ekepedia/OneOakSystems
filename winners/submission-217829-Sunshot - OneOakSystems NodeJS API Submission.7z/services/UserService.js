/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service provides methods to manage users.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var User = require('../models/index').User;

/**
 * Creates a user.
 * 
 * @param user
 *            {Object} the user.
 * @param callback
 *            {Function<error:Error, user:User>} the callback function.
 */
exports.create = function(user, callback) {
    User.create(user, callback);
};

/**
 * Gets a user.
 * 
 * @param id
 *            {String} the id.
 * @param callback
 *            {Function<error:Error, user:User>} the callback function.
 */
exports.get = function(id, callback) {
    User.findOne({
        _id : id
    }, callback);
};

/**
 * Gets all users.
 * 
 * @param callback
 *            {Function<error:Error, users:[User]>} the callback function.
 */
exports.getAll = function(callback) {
    User.find({}, callback);
};

