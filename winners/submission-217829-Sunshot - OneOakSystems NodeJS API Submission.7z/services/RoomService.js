/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service provides methods to manage rooms.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var Room = require('../models/index').Room,
    _ = require('underscore'),
    NotFoundError = require('../errors/NotFoundError');

/**
 * Creates a room.
 * 
 * @param room
 *            {Room} the room.
 * @param callback
 *            {Function<error:Error, room:Room>} the callback function.
 */
exports.create = function(room, callback) {
    Room.create(room, callback);
};

/**
 * Updates a room.
 * 
 * @param id
 *            {String} the room id.
 * @param updated
 *            {Object} the updated fields.
 * 
 * @param callback
 *            {Function<error:Error, room:Room>} the callback function.
 */
exports.update = function(id, updated, callback) {
    Room.findOne({
        _id : id
    }, function(err, existing) {
        if (err) {
            callback(err);
        } else if (existing !== null) {
            _.each(updated, function(value, name) {
                existing[name] = value;
            });
            existing.save(callback);
        } else {
            callback(new NotFoundError('Room with id ' + id + ' is not found.'));
        }
    });
};

/**
 * Gets a room.
 * 
 * @param id
 *            {String} the room id.
 * @param callback
 *            {Function<error:Error, room:Room>} the callback function.
 */
exports.get = function(id, callback) {
    Room.findOne({
        _id : id
    }, callback);
};

/**
 * Gets a room name.
 * 
 * @param id
 *            {String} the room id.
 * @param callback
 *            {Function<error:Error, roomName:String>} the callback function.
 */
exports.getName = function(id, callback) {
    Room.findOne({
        _id : id
    }, function(err, result) {
        if (err) {
            callback(err);
        } else if (result !== null) {
            callback(null, result.roomName);
        } else {
            callback(null, null);
        }
    });
};
