/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service provides methods to manage house status.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var HouseStatus = require('../models/index').HouseStatus;

/**
 * Gets house statuses.
 * 
 * @param houseId
 *            {String} the house id.
 * @param callback
 *            {Function<error:Error, houseStatuses:[HouseStatus]>} the callback function.
 */
exports.get = function(houseId, callback) {
    HouseStatus.find({
        houseId : houseId
    }, callback);
};

/**
 * Gets a current house status.
 * 
 * @param houseId
 *            {String} the house id.
 * @param callback
 *            {Function<error:Error, houseStatuses:[HouseStatus]>} the callback function.
 */
exports.getCurrent = function(houseId, callback) {
    HouseStatus.find({
        houseId : houseId
    }).sort({
        "timestamp" : "desc"
    }).exec(function(err, result) {
        if (err) {
            callback(err);
        } else if (result.length > 0) {
            callback(null, result[0]);
        } else {
            callback(null, null);
        }
    });
};
