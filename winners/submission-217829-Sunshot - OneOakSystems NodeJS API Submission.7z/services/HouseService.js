/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service provides methods to manage houses.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var House = require('../models/index').House;

/**
 * Gets a house.
 * 
 * @param id
 *            {String} the house id.
 * @param callback
 *            {Function<error:Error, house:House>} the callback function.
 */
exports.get = function(id, callback) {
    House.findOne({
        _id : id
    }, callback);
};

