/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service provides methods to manage room alerts.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var RoomAlerts = require('../models/index').RoomAlerts,
    async = require('async');

/**
 * Gets room alerts by room ids.
 * 
 * @param roomIds
 *            {String} the room ids.
 * @param offset
 *            {String} the offset.
 * @param limit
 *            {String} the limit.
 * @param callback
 *            {Function<error:Error, roomAlerts:[RoomAlerts], count:Number>} the callback function.
 */
exports.getByRoomIds = function(roomIds, offset, limit, callback) {
    async.waterfall([ function(cb) {
        RoomAlerts.find({
            roomId : {
                $in : roomIds
            }
        }).count(cb);
    }, function(count, cb) {
        RoomAlerts.find({
            roomId : {
                $in : roomIds
            }
        }).limit(limit).skip(offset).exec(function(err, result) {
            if (err) {
                cb(err);
            } else {
                cb(null, result, count);
            }
        });
    } ], function(err, result, count) {
        if (err) {
            callback(err);
        } else {
            callback(null, result, count);
        }
    });
};

/**
 * Gets room alerts by room ids and status.
 * 
 * @param roomIds
 *            {String} the room ids.
 * @param status
 *            {String} the status.
 * @param offset
 *            {String} the offset.
 * @param limit
 *            {String} the limit.
 * @param callback
 *            {Function<error:Error, roomAlerts:[RoomAlerts], count:Number>} the callback function.
 */
exports.getByRoomIdsStatus = function(roomIds, status, offset, limit, callback) {
    async.waterfall([ function(cb) {
        RoomAlerts.find({
            roomId : {
                $in : roomIds
            },
            status : status
        }).count(cb);
    }, function(count, cb) {
        RoomAlerts.find({
            roomId : {
                $in : roomIds
            },
            status : status
        }).limit(limit).skip(offset).exec(function(err, result) {
            if (err) {
                cb(err);
            } else {
                cb(null, result, count);
            }
        });
    } ], function(err, result, count) {
        if (err) {
            callback(err);
        } else {
            callback(null, result, count);
        }
    });
};
