/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This service provides methods to manage session tokens.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var SessionToken = require('../models/index').SessionToken;

/**
 * Gets the user token.
 * 
 * @param token
 *            {String} the token.
 * @param callback
 *            {Function<error:Error, sessionToken:SessionToken>} the callback function.
 */
exports.get = function(token, callback) {
    SessionToken.findOne({
        token : token
    }, callback);
};
