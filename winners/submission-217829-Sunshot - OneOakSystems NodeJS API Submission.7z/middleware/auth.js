/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Application auth middleware. This middleware authorizes the user of given operation. This middleware is added after
 * tokenParser. This middleware is added only for secured routes.
 * 
 * @author TCSCODER
 * @version 1.0
 */
"use strict";

var ForbiddenError = require('../errors/ForbiddenError'),
    SecurityService = require('../services/SecurityService'),
    logResponseAndError = require("../helpers/logging").logResponseAndError;

function authenAction(action) {
    return function(req, res, next) {
        var auth = req.headers.authorization;
        if (auth) {
            var splitted = auth.split(' ');
            if (splitted.length !== 2) {
                return logResponseAndError(new ForbiddenError('Invalid Authorization Header'), res);
            }
            var buf = new Buffer(splitted[1], 'base64'), plainAuth = buf.toString();

            var plainAuthSplitted = plainAuth.split(':');
            if (splitted[0] === 'Bearer') {
                req.auth = {
                    type : 'Bearer',
                    token : splitted[1]
                };
            } else {
                return logResponseAndError(new ForbiddenError('Invalid Authorization Header'), res);
            }
        }

        if (req.auth && req.auth.token) {
            SecurityService.authenticateWithSessionToken(req.auth.token, function(err, user, expirationDate) {
                if (err) {
                    return logResponseAndError(err, res);
                } else {
                    req.user = user;
                    res.header('Session-Expires-In', expirationDate - (new Date()).getTime());
                    next();
                }
            });

        } else {
            return logResponseAndError(new ForbiddenError('User is not authenticated'), res);
        }
    };
}

module.exports = authenAction;
