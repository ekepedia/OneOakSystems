/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Validation error. The Default HTTP STATUS CODE is 400.
 * 
 * @author TCSCODER
 * @version 1.0
 */
"use strict";

var util = require('util'),
    HTTP_BAD_REQUEST = 400,
    NAME = 'ValidationError';

function ValidationError(message) {
    Error.call(this);
    Error.captureStackTrace(this);
    this.name = NAME;
    this.message = message;
    this.code = HTTP_BAD_REQUEST;
}

util.inherits(ValidationError, Error);
ValidationError.prototype.name = 'ValidationError';

module.exports = ValidationError;
