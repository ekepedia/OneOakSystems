/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Not Found error. The Default HTTP STATUS CODE is 404.
 * 
 * @author TCSCODER
 * @version 1.0
 */
"use strict";

var util = require('util'),
    HTTP_NOT_FOUND = 404,
    NAME = 'NotFoundError';

function NotFoundError(message) {
    Error.call(this);
    Error.captureStackTrace(this);
    this.name = NAME;
    this.message = message;
    this.code = HTTP_NOT_FOUND;
}

util.inherits(NotFoundError, Error);
NotFoundError.prototype.name = 'NotFoundError';

module.exports = NotFoundError;
