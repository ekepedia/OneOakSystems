/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Unauthorized error. The Default HTTP STATUS CODE is 401.
 * 
 * @author TCSCODER
 * @version 1.0
 */
"use strict";

var util = require('util'),
    HTTP_UNAUTHORIZED = 401,
    NAME = 'UnauthorizedError';

function UnauthorizedError(message) {
    Error.call(this);
    Error.captureStackTrace(this);
    this.name = NAME;
    this.message = message;
    this.code = HTTP_UNAUTHORIZED;
}

util.inherits(UnauthorizedError, Error);
UnauthorizedError.prototype.name = 'UnauthorizedError';

module.exports = UnauthorizedError;
