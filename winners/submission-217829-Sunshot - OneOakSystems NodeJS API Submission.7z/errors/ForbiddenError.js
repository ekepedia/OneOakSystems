/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Forbidden error. The Default HTTP STATUS CODE is 403.
 * 
 * @author TCSCODER
 * @version 1.0
 */
"use strict";

var util = require('util'),
    HTTP_FORBIDDEN = 403,
    NAME = 'ForbiddenError';

function ForbiddenError(message) {
    Error.call(this);
    Error.captureStackTrace(this);
    this.name = NAME;
    this.message = message;
    this.code = HTTP_FORBIDDEN;
}

util.inherits(ForbiddenError, Error);
ForbiddenError.prototype.name = 'ForbiddenError';

module.exports = ForbiddenError;
