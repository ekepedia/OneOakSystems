/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This controller provides room related api.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var RoomService = require('../services/RoomService'),
    RoomScheduleService = require('../services/RoomScheduleService'),
    RoomTemperatureService = require('../services/RoomTemperatureService'),
    RoomAlertsService = require('../services/RoomAlertsService'),
    HouseUserService = require('../services/HouseUserService'),
    RoomPlotService = require('../services/RoomPlotService'),
    UnauthorizedError = require('../errors/UnauthorizedError'),
    NotFoundError = require('../errors/NotFoundError'),
    ValidationError = require('../errors/ValidationError'),
    wrapExpress = require('../helpers/logging').wrapExpress,
    async = require('async'),
    helper = require('../helpers/helper'),
    config = require('../config/config'),
    _ = require('underscore');

/**
 * Adds or Updates a room.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function setRoom(req, callback) {
    var room = req.body;
    var roomId = room.roomId;
    if (room.hasOwnProperty("roomId")) {
        helper.checkObjectId(roomId, 'roomId');
        if (room.hasOwnProperty("houseId")) {
            helper.checkObjectId(room.houseId, 'houseId');
        }
        if (room.hasOwnProperty("bundleId")) {
            helper.checkStringNotNullNotEmpty(room.bundleId, 'bundleId');
        }
        if (room.hasOwnProperty("description")) {
            helper.checkStringNotNullNotEmpty(room.description, 'description');
        }
        if (room.hasOwnProperty("size")) {
            helper.checkRoomSize(room.size, 'size');
        }
        if (room.hasOwnProperty("ventsCount")) {
            helper.checkPositiveNumber(room.ventsCount, 'ventsCount');
        }
        if (room.hasOwnProperty("windowsCount")) {
            helper.checkPositiveNumber(room.windowsCount, 'windowsCount');
        }
        helper.checkSchedule(room.schedule, 'schedule');
    } else {
        helper.checkObjectId(room.houseId, 'houseId');
        helper.checkStringNotNullNotEmpty(room.bundleId, 'bundleId');
        helper.checkStringNotNullNotEmpty(room.description, 'description');
        helper.checkRoomSize(room.size, 'size');
        helper.checkPositiveNumber(room.ventsCount, 'ventsCount');
        helper.checkPositiveNumber(room.windowsCount, 'windowsCount');
        helper.checkSchedule(room.schedule, 'schedule');
    }

    var schedule = room.schedule;
    delete room.schedule;
    var userId = req.user._id;

    if (!room.hasOwnProperty("roomId")) {
        async.waterfall([ function(cb) {
            HouseUserService.getRole(room.houseId, userId, function(err, role) {
                if (err) {
                    cb(err);
                } else if (!role || (role != 'admin' && role != 'user' && role != 'operator')) {
                    cb(new UnauthorizedError('User is not authorized'));
                } else {
                    cb(null);
                }
            });
        }, function(cb) {
            room.roomName = room.bundleId;
            delete room.bundleId;
            RoomService.create(room, function(err, result) {
                if (err) {
                    cb(err);
                } else {
                    var response = JSON.parse(JSON.stringify(result));
                    cb(null, response);
                }
            });
        }, function(response, cb) {
            RoomScheduleService.create(response._id, schedule, function(err, result) {
                if (err) {
                    cb(err);
                } else {
                    response.schedule = result;
                    cb(null, response);
                }
            });
        } ], function(err, result) {
            if (err) {
                callback(err);
            } else {
                callback(null, result);
            }
        });
    } else {
        async.waterfall([ function(cb) {
            RoomService.get(roomId, cb);
        }, function(room, cb) {
            if (!room) {
                cb(new NotFoundError('Room with id ' + roomId + ' is not found.'));
            } else {
                HouseUserService.getRole(room.houseId, userId, function(err, role) {
                    if (err) {
                        cb(err);
                    } else if (!role || (role != 'admin' && role != 'operator' && role != 'user')) {
                        cb(new UnauthorizedError('User is not authorized'));
                    } else {
                        cb(null);
                    }
                });
            }
        }, function(cb) {
            var updated = {};
            if (room.hasOwnProperty("houseId")) {
                updated.houseId = room.houseId;
            }
            if (room.hasOwnProperty("bundleId")) {
                updated.roomName = room.bundleId;
            }
            if (room.hasOwnProperty("description")) {
                updated.description = room.description;
            }
            if (room.hasOwnProperty("size")) {
                updated.size = room.size;
            }
            if (room.hasOwnProperty("ventsCount")) {
                updated.ventsCount = room.ventsCount;
            }
            if (room.hasOwnProperty("windowsCount")) {
                updated.windowsCount = room.windowsCount;
            }
            RoomService.update(roomId, updated, function(err, result) {
                if (err) {
                    cb(err);
                } else {
                    var response = JSON.parse(JSON.stringify(result));
                    cb(null, response);
                }
            });
        }, function(response, cb) {
            if (schedule.length > 0) {
                RoomScheduleService.create(roomId, schedule, function(err, result) {
                    if (err) {
                        cb(err);
                    } else {
                        response.schedule = result;
                        cb(null, response);
                    }
                });
            } else {
                cb(null, response);
            }
        } ], function(err, result) {
            if (err) {
                callback(err);
            } else {
                callback(null, result);
            }
        });
    }
}

/**
 * Gets a room details.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getRoom(req, callback) {
    var sessionToken = req.auth.token;
    var id = req.params.id;
    helper.checkObjectId(id, 'roomId');

    var userId = req.user._id;
    var response;
    async.waterfall([ function(cb) {
        RoomService.get(id, cb);
    }, function(room, cb) {
        if (!room) {
            cb(new NotFoundError('Room with id ' + id + ' is not found.'));
        } else {
            HouseUserService.getRole(room.houseId, userId, function(err, role) {
                if (err) {
                    cb(err);
                } else if (!role) {
                    cb(new UnauthorizedError('User is not authorized'));
                } else {
                    cb(null, room);
                }
            });
        }
    }, function(room, cb) {
        response = JSON.parse(JSON.stringify(room));
        RoomScheduleService.getLatestByRoom(id, function(err, result) {
            if (err) {
                cb(err);
            } else {
                response.roomSchedule = result;
                cb(null, response);
            }
        });
    }, function(response, cb) {
        RoomTemperatureService.getLatestByRoom(id, function(err, result) {
            if (err) {
                cb(err);
            } else {
                response.roomTemperature = result;
                cb(null, response);
            }
        });
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

/**
 * Retrieves Alerts of selected rooms.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getAlerts(req, callback) {
    var ids = req.query.ids;
    helper.checkNotNull(ids, 'roomIds');
    if (!_.isArray(ids)) {
        ids = [ ids ];
    }
    ids.forEach(function(id) {
        helper.checkObjectId(id, 'roomId');
    })
    var status = req.query.status;
    var offset = req.query.offset || config.OFFSET;
    var limit = req.query.limit || config.LIMIT;
    helper.checkAlertStatus(status);
    helper.checkPositiveNumber(offset, 'offset');
    helper.checkPositiveNumber(limit, 'limit');

    var userId = req.user._id;
    var response;
    async.waterfall([ function(cb) {
        async.map(ids, function(id, cb2) {
            async.waterfall([ function(cb3) {
                RoomService.get(id, cb3);
            }, function(room, cb3) {
                if (!room) {
                    cb3(new NotFoundError('Room with id ' + id + ' is not found.'));
                } else {
                    HouseUserService.getRole(room.houseId, userId, function(err, role) {
                        if (err) {
                            cb3(err);
                        } else if (!role) {
                            cb3(new UnauthorizedError('User is not authorized'));
                        } else {
                            cb3(null);
                        }
                    });
                }
            } ], function(err) {
                if (err) {
                    cb2(err);
                } else {
                    cb2(null);
                }
            });
        }, function(err) {
            if (err) {
                cb(err);
            } else {
                cb(null);
            }
        });
    }, function(cb) {
        if (status) {
            RoomAlertsService.getByRoomIdsStatus(ids, status, offset, limit, cb);
        } else {
            RoomAlertsService.getByRoomIds(ids, offset, limit, cb);
        }
    }, function(roomAlerts, count, cb) {
        async.map(roomAlerts, function(roomAlert, cb2) {
            RoomService.getName(roomAlert.roomId, function(err, result) {
                if (err) {
                    cb2(err);
                } else {
                    roomAlert = JSON.parse(JSON.stringify(roomAlert));
                    roomAlert.roomName = result;
                    cb2(null, roomAlert);
                }
            })
        }, function(err, roomAlerts) {
            if (err) {
                cb(err);
            } else {
                var response = {};
                response.count = count;
                response.offset = offset;
                response.limit = limit;
                response.items = roomAlerts;
                cb(null, response);
            }
        });
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

/**
 * Handles saving changes.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function setRoomTemperature(req, callback) {
    var roomId = req.params.id;
    helper.checkObjectId(roomId, 'roomId');
    var roomTemperature = req.body;
    helper.checkUserComfortLevel(roomTemperature.userComfortLevel);
    helper.checkNumber(roomTemperature.targetTemperatureValue, 'roomTemperature.targetTemperatureValue');

    var userId = req.user._id;
    roomTemperature.roomId = roomId;
    async.waterfall([ function(cb) {
        RoomService.get(roomId, cb);
    }, function(room, cb) {
        if (!room) {
            cb(new NotFoundError('Room with id ' + roomId + ' is not found.'));
        } else {
            HouseUserService.getRole(room.houseId, userId, function(err, role) {
                if (err) {
                    cb(err);
                } else if (!role || (role != 'admin' && role != 'user')) {
                    cb(new UnauthorizedError('User is not authorized'));
                } else {
                    cb(null);
                }
            });
        }
    }, function(cb) {
        RoomTemperatureService.create(roomTemperature, cb);
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });

}

/**
 * Retrieves room latest temperature value.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getRoomTemperature(req, callback) {
    var roomId = req.params.id;
    helper.checkObjectId(roomId, 'roomId');

    var userId = req.user._id;
    async.waterfall([ function(cb) {
        RoomService.get(roomId, cb);
    }, function(room, cb) {
        if (!room) {
            cb(new NotFoundError('Room with id ' + roomId + ' is not found.'));
        } else {
            HouseUserService.getRole(room.houseId, userId, function(err, role) {
                if (err) {
                    cb(err);
                } else if (!role) {
                    cb(new UnauthorizedError('User is not authorized'));
                } else {
                    cb(null);
                }
            });
        }
    }, function(cb) {
        RoomTemperatureService.getLatestByRoom(roomId, cb);
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

/**
 * Retrieves plot data for chart.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getRoomTemperaturePlotData(req, callback) {
    var ids = req.query.ids;
    var roomIds = ids.split(',');
    roomIds.forEach(function(roomId) {
        helper.checkObjectId(roomId, 'roomId');
    })
    var startDate = req.query.startDate;
    var endDate = req.query.endDate;
    if (!startDate && !endDate) {
        var now = new Date();
        startDate = new Date(now.getTime() - 1000 * 60 * 60 * 24)
        endDate = now;
    } else {
        if ((startDate && !endDate) || (!startDate && endDate)) {
            throw new ValidationError('startDate and endDate should be all set.');
        }
        helper.checkDate(startDate, 'startDate');
        helper.checkDate(endDate, 'endDate');
        startDate = new Date(startDate);
        endDate = new Date(endDate);
        if (endDate.getTime() <= startDate.getTime()) {
            throw new ValidationError('endDate must be larger than startDate.');
        }
    }

    var userId = req.user._id;
    async.waterfall([
            function(cb) {
                async.map(roomIds, function(roomId, cb2) {
                    async.waterfall([ function(cb3) {
                        RoomService.get(roomId, cb3);
                    }, function(room, cb3) {
                        if (!room) {
                            cb3(new NotFoundError('Room with id ' + roomId + ' is not found.'));
                        } else {
                            HouseUserService.getRole(room.houseId, userId, function(err, role) {
                                if (err) {
                                    cb3(err);
                                } else if (!role) {
                                    cb3(new UnauthorizedError('User is not authorized'));
                                } else {
                                    cb3(null);
                                }
                            });
                        }
                    } ], function(err) {
                        if (err) {
                            cb2(err);
                        } else {
                            cb2(null);
                        }
                    });
                }, function(err) {
                    if (err) {
                        cb(err);
                    } else {
                        cb(null);
                    }
                });
            },
            function(cb) {
                RoomPlotService.get(roomIds, startDate, endDate, function(err, timestamps, avgCurrentTempData,
                        avgOutsideTempData, avgDesiredTempData) {
                    if (err) {
                        callback(err);
                    } else {
                        var response = [];
                        response.push(timestamps);
                        response.push(avgCurrentTempData);
                        response.push(avgOutsideTempData);
                        response.push(avgDesiredTempData);

                        cb(null, response);
                    }
                });
            } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

/**
 * Sets multiple rooms schedules.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function setRoomSchedule(req, callback) {
    var roomSchedules = req.body.roomSchedules;
    helper.checkArrayNotNullNotEmpty(roomSchedules, 'roomSchedules');
    var roomIds = [];
    roomSchedules.forEach(function(roomSchedule) {
        helper.checkObjectId(roomSchedule.roomId, 'roomSchedule.roomId');
        helper.checkSchedule(roomSchedule.schedule, 'roomSchedule.schedule');
        var found = false;
        roomIds.forEach(function(roomId) {
            if (roomId == roomSchedule.roomId) {
                found = true;
            }
        })
        if (!found) {
            roomIds.push(roomSchedule.roomId);
        }
    });

    var userId = req.user._id;
    async.waterfall([ function(cb) {
        async.map(roomIds, function(roomId, cb2) {
            async.waterfall([ function(cb3) {
                RoomService.get(roomId, cb3);
            }, function(room, cb3) {
                if (!room) {
                    cb3(new NotFoundError('Room with id ' + roomId + ' is not found.'));
                } else {
                    HouseUserService.getRole(room.houseId, userId, function(err, role) {
                        if (err) {
                            cb3(err);
                        } else if (!role || (role != 'admin' && role != 'user' && role != 'operator')) {
                            cb3(new UnauthorizedError('User is not authorized'));
                        } else {
                            cb3(null);
                        }
                    });
                }
            } ], function(err) {
                if (err) {
                    cb2(err);
                } else {
                    cb2(null);
                }
            });
        }, function(err) {
            if (err) {
                cb(err);
            } else {
                cb(null);
            }
        });
    }, function(cb) {
        async.map(roomSchedules, function(roomSchedule, cb2) {
            RoomScheduleService.create(roomSchedule.roomId, roomSchedule.schedule, function(err, result) {
                if (err) {
                    cb2(err);
                } else {
                    cb2(null, roomSchedule);
                }
            })
        }, function(err, roomSchedules) {
            if (err) {
                cb(err);
            } else {
                cb(null, roomSchedules);
            }
        });
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });

}

/**
 * Gets latest rooms schedule.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getRoomSchedule(req, callback) {
    var ids = req.query.ids;
    var roomIds = ids.split(',');
    roomIds.forEach(function(roomId) {
        helper.checkObjectId(roomId, 'roomId');
    })

    var userId = req.user._id;
    var response = [];
    async.waterfall([ function(cb) {
        async.map(roomIds, function(roomId, cb2) {
            async.waterfall([ function(cb3) {
                RoomService.get(roomId, cb3);
            }, function(room, cb3) {
                if (!room) {
                    cb3(new NotFoundError('Room with id ' + roomId + ' is not found.'));
                } else {
                    HouseUserService.getRole(room.houseId, userId, function(err, role) {
                        if (err) {
                            cb3(err);
                        } else if (!role) {
                            cb3(new UnauthorizedError('User is not authorized'));
                        } else {
                            cb3(null);
                        }
                    });
                }
            } ], function(err) {
                if (err) {
                    cb2(err);
                } else {
                    cb2(null);
                }
            });
        }, function(err) {
            if (err) {
                cb(err);
            } else {
                cb(null);
            }
        });
    }, function(cb) {
        async.map(roomIds, function(roomId, cb2) {
            RoomScheduleService.getLatestByRoom(roomId, function(err, result) {
                if (err) {
                    cb2(err);
                } else {
                    response.push(result);
                    cb2(null, response);
                }
            })
        }, function(err, response) {
            if (err) {
                cb(err);
            } else {
                cb(null, response);
            }
        });
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

module.exports = {
    setRoom : wrapExpress('RoomController#setRoom', setRoom),
    getRoom : wrapExpress('RoomController#getRoom', getRoom),
    getAlerts : wrapExpress('RoomController#getAlerts', getAlerts),
    setRoomTemperature : wrapExpress('RoomController#setRoomTemperature', setRoomTemperature),
    getRoomTemperature : wrapExpress('RoomController#getRoomTemperature', getRoomTemperature),
    getRoomTemperaturePlotData : wrapExpress('RoomController#getRoomTemperaturePlotData', getRoomTemperaturePlotData),
    setRoomSchedule : wrapExpress('RoomController#setRoomSchedule', setRoomSchedule),
    getRoomSchedule : wrapExpress('RoomController#getRoomSchedule', getRoomSchedule)
};
