/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This controller provides house related api.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var UserService = require('../services/UserService'),
    HouseService = require('../services/HouseService'),
    HouseInfoService = require('../services/HouseInfoService'),
    HouseStatusService = require('../services/HouseStatusService'),
    HouseUserService = require('../services/HouseUserService'),
    UnauthorizedError = require('../errors/UnauthorizedError'),
    NotFoundError = require('../errors/NotFoundError'),
    wrapExpress = require('../helpers/logging').wrapExpress,
    async = require('async'),
    helper = require('../helpers/helper'),
    config = require('../config/config'),
    bcrypt = require('bcrypt-nodejs'),
    mail = require('../helpers/mail-helper');

/**
 * Returns houses of the user.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getHouses(req, callback) {
    var offset = req.query.offset || config.OFFSET;
    var limit = req.query.limit || config.LIMIT;
    helper.checkPositiveNumber(offset, 'offset');
    helper.checkPositiveNumber(limit, 'limit');
    var userId = req.user._id;
    async.waterfall([ function(cb) {
        HouseUserService.getHouseIds(userId, offset, limit, cb);
    }, function(houseUsers, count, cb) {
        var houseIds = [];
        houseUsers.forEach(function(houseUser) {
            houseIds.push(houseUser.houseId);
        });
        async.map(houseIds, function(houseId, cb2) {
            HouseService.get(houseId, function(err, result) {
                if (err) {
                    cb2(err);
                } else {
                    cb2(null, result);
                }
            })
        }, function(err, items) {
            var response = {};
            response.count = count;
            response.offset = offset;
            response.limit = limit;
            response.items = items;
            if (err) {
                cb(err);
            } else {
                cb(null, response);
            }
        });
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

/**
 * Returns house information.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getHouse(req, callback) {
    var id = req.params.id;
    helper.checkObjectId(id, "houseId");
    var userId = req.user._id;
    var response;
    async.waterfall([ function(cb) {
        HouseUserService.getRole(id, userId, function(err, role) {
            if (err) {
                cb(err);
            } else if (!role) {
                cb(new UnauthorizedError('User is not authorized'));
            } else {
                cb(null);
            }
        });
    }, function(cb) {
        HouseService.get(id, cb);
    }, function(house, cb) {
        var response = JSON.parse(JSON.stringify(house));
        async.series([ function(cb) {
            HouseInfoService.get(id, function(err, result) {
                if (err) {
                    cb(err);
                } else {
                    cb(null, result);
                }
            })
        }, function(cb) {
            HouseStatusService.get(id, function(err, result) {
                if (err) {
                    cb(err);
                } else {
                    cb(null, result);
                }
            })
        } ], function(err, result) {
            if (err) {
                callback(err);
            } else {
                response.info = result[0];
                response.statuses = result[1];
                callback(null, response);
            }
        });
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

/**
 * Retrieves the current status.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getStatus(req, callback) {
    var sessionToken = req.auth.token;
    var id = req.params.id;
    helper.checkObjectId(id, "houseId");
    var userId = req.user._id;
    var response = {};
    async.waterfall([ function(cb) {
        HouseUserService.getRole(id, userId, function(err, role) {
            if (err) {
                cb(err);
            } else if (!role) {
                cb(new UnauthorizedError('User is not authorized'));
            } else {
                cb(null);
            }
        });
    }, function(cb) {
        HouseStatusService.getCurrent(id, cb);
    }, function(houseStatus, cb) {
        response.houseStatus = JSON.parse(JSON.stringify(houseStatus));
        HouseInfoService.get(id, function(err, result) {
            if (err) {
                cb(err);
            } else {
                response.temperatureUnit = result.temperatureUnit;
                cb(null, response);
            }
        });
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

/**
 * Edits or adds new user.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function setHouseUser(req, callback) {
    var houseUser = req.body;
    helper.checkObjectId(houseUser.houseId, "houseUser.houseId");
    if (!houseUser.hasOwnProperty("userId")) {
        helper.checkStringNotNullNotEmpty(houseUser.fullName, "houseUser.fullName");
        helper.checkStringNotNullNotEmpty(houseUser.email, "houseUser.email");
    } else {
        helper.checkObjectId(houseUser.userId, "user.userId");
    }
    helper.checkRole(houseUser.role, "houseUser.role");

    var userId = req.user._id;
    async.waterfall([ function(cb) {
        HouseUserService.getRole(houseUser.houseId, userId, function(err, role) {
            if (err) {
                cb(err);
            } else if (!role || role != 'admin') {
                cb(new UnauthorizedError('User is not authorized'));
            } else {
                cb(null);
            }
        });
    }, function(cb) {
        if (!houseUser.hasOwnProperty("userId")) {
            async.waterfall([ function(cb2) {
                bcrypt.genSalt(config.SALT_WORK_FACTOR, function(err, salt) {
                    cb2(err, houseUser, salt);
                });
            }, function(houseUser, salt, cb2) {
                var generatedPassword = '';
                var values = 'abcdefghijklmnopqrstuvwxyz0123456789';
                for ( var i = 0; i < 8; i++) {
                    generatedPassword += values[parseInt(Math.random() * 36)];
                }
                bcrypt.hash(generatedPassword, salt, null, function(err, hash) {
                    cb2(err, houseUser, hash, generatedPassword);
                });
            }, function(user, hash, generatedPassword, cb2) {
                var user = {};
                user.fullName = houseUser.fullName;
                user.email = houseUser.email;
                user.password = hash;
                delete houseUser.fullName;
                delete houseUser.email;
                UserService.create(user, function(err, result) {
                    if (err) {
                        cb2(err);
                    } else {
                        result.generatedPassword = generatedPassword;
                        cb2(null, result);
                    }
                });
            } ], function(err, result) {
                if (err) {
                    cb(err);
                } else {
                    cb(null, result);
                }
            });
        } else {
            UserService.get(houseUser.userId, cb);
        }
    }, function(user, cb) {
        if (!user) {
            cb(new NotFoundError('User is not found'));
        } else {
            var fullName = user.fullName;
            var email = user.email;

            var values = {};
            values.fullName = fullName;
            values.role = houseUser.role;
            values.houseId = houseUser._id;
            if (user.generatedPassword) {
                values.generatedPassword = user.generatedPassword;
            }

            mail.renderEmailTemplate('houseUser', values, function(err, html) {
                if (err) {
                    cb(err);
                } else {
                    var sender = config.SITE_ADMIN_EMAIL;
                    var receiver = email;
                    var subject = "Grant house permission";
                    var content = html;
                    mail.sendMail(sender, receiver, subject, content, function(err, result) {
                        cb(null, user)
                    });
                }
            });
        }
    }, function(user, cb) {
        if (!houseUser.userId) {
            houseUser.userId = user._id;
        }
        HouseUserService.createOrUpdate(houseUser, userId, cb);
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

/**
 * Gets users of specific house.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getHouseUsers(req, callback) {
    var houseId = req.params.id;
    helper.checkStringNotNullNotEmpty(houseId, "houseId");

    var offset = req.query.offset || config.OFFSET;
    var limit = req.query.limit || config.LIMIT;
    helper.checkPositiveNumber(offset, 'offset');
    helper.checkPositiveNumber(limit, 'limit');

    var userId = req.user._id;
    async.waterfall([ function(cb) {
        HouseUserService.getRole(houseId, userId, function(err, role) {
            if (err) {
                cb(err);
            } else if (!role) {
                cb(new UnauthorizedError('User is not authorized'));
            } else {
                cb(null);
            }
        });
    }, function(cb) {
        HouseUserService.getUserIds(houseId, offset, limit, cb);
    }, function(houseUsers, count, cb) {
        var userIds = [];
        houseUsers.forEach(function(houseUser) {
            userIds.push(houseUser.userId);
        });
        async.map(userIds, function(userId, cb2) {
            UserService.get(userId, function(err, result) {
                if (err) {
                    cb2(err);
                } else {
                    cb2(null, result);
                }
            })
        }, function(err, items) {
            if (err) {
                cb(err);
            } else {
                var response = {};
                response.count = count;
                response.offset = offset;
                response.limit = limit;
                response.items = items;
                cb(null, response);
            }
        });
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

/**
 * Removes user association with a house.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function removeHouseUser(req, callback) {
    var houseId = req.params.id;
    var userId = req.params.userId;
    helper.checkObjectId(houseId, "houseId");
    helper.checkObjectId(userId, "userId");

    var loginUserId = req.user._id;
    async.waterfall([ function(cb) {
        HouseUserService.getRole(houseId, loginUserId, function(err, role) {
            if (err) {
                cb(err);
            } else if (!role || role != 'admin') {
                cb(new UnauthorizedError('User is not authorized'));
            } else {
                cb(null);
            }
        });
    }, function(callback) {
        HouseUserService.remove(houseId, userId, callback);
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

/**
 * Calculate Savings.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function calculateSavings(req, callback) {
    var houseId = req.params.id;
    helper.checkObjectId(houseId, "houseId");

    var userId = req.user._id;
    async.waterfall([ function(cb) {
        HouseUserService.getRole(houseId, userId, function(err, role) {
            if (err) {
                cb(err);
            } else if (!role) {
                cb(new UnauthorizedError('User is not authorized'));
            } else {
                cb(null);
            }
        });
    }, function(cb) {
        cb(null, {
            savings_percentage : 20,
            savings_per_day : 100
        });
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

module.exports = {
    getHouses : wrapExpress('HouseController#getHouses', getHouses),
    getHouse : wrapExpress('HouseController#getHouse', getHouse),
    getStatus : wrapExpress('HouseController#getStatus', getStatus),
    setHouseUser : wrapExpress('HouseController#setHouseUser', setHouseUser),
    getHouseUsers : wrapExpress('HouseController#getHouseUsers', getHouseUsers),
    removeHouseUser : wrapExpress('HouseController#removeHouseUser', removeHouseUser),
    calculateSavings : wrapExpress('HouseController#calculateSavings', calculateSavings)
};
