/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * This controller provides user related api.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var UserService = require('../services/UserService'),
    SecurityService = require('../services/SecurityService'),
    NotFoundError = require('../errors/NotFoundError'),
    wrapExpress = require('../helpers/logging').wrapExpress,
    async = require('async'),
    helper = require('../helpers/helper'),
    _ = require('underscore');

/**
 * Signs up.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function signUp(req, callback) {
    var user = req.body;
    helper.checkStringNotNullNotEmpty(user.fullName, "user.fullName");
    helper.checkEmail(user.email, "user.email");
    helper.checkStringNotNullNotEmpty(user.password, "user.password");
    async.waterfall([ function(cb) {
        SecurityService.generateHash(user.password, cb)
    }, function(hash, cb) {
        _.extend(user, {
            password : hash
        });
        UserService.create(user, cb);
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

/**
 * Signs in.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function signIn(req, callback) {
    var user = req.body;
    helper.checkEmail(user.email, "user.email");
    helper.checkStringNotNullNotEmpty(user.password, "user.password");

    async.waterfall([ function(cb) {
        SecurityService.authenticate(user.email, user.password, cb);
    }, function(user, cb) {
        SecurityService.generateSessionToken(user._id, cb);
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, {
                sessionToken : result
            });
        }
    });
}

/**
 * Gets the user for login user.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getMe(req, callback) {
    callback(null, req.user);
}

/**
 * Gets User information.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getUser(req, callback) {
    var id = req.params.id;
    helper.checkObjectId(id, "userId");

    UserService.get(id, function(err, result) {
        if (err) {
            callback(err);
        } else {
            if (result) {
                delete result.password;
                callback(null, result);
            } else {
                callback(new NotFoundError('User is not found.'));
            }
        }
    });
}

/**
 * Gets list of all users in the application.
 * 
 * @param req
 *            {Object} the request object.
 * @param callback
 *            {Function} the callback function.
 */
function getUsers(req, callback) {
    async.waterfall([ function(cb) {
        UserService.getAll(cb);
    } ], function(err, result) {
        if (err) {
            callback(err);
        } else {
            callback(null, result);
        }
    });
}

module.exports = {
    signUp : wrapExpress('UserController#signUp', signUp),
    signIn : wrapExpress('UserController#signIn', signIn),
    getMe : wrapExpress('UserController#getMe', getMe),
    getUser : wrapExpress('UserController#getUser', getUser),
    getUsers : wrapExpress('UserController#getUsers', getUsers)
};
