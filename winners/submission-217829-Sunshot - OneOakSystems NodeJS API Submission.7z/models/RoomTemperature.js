/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents room temperature.
 * 
 * @version 1.0
 * @author TCSCODER
 */
'use strict';

var Schema = require('mongoose').Schema,
    ObjectId = Schema.ObjectId;

var RoomTemperatureSchema = new Schema({
    roomId : {
        type : ObjectId,
        required : true
    },
    userComfortLevel : {
        type : String,
        required : true,
        enum: ['cold', 'cool', 'perfect', 'warm', 'hot', 'custom']
    },
    targetTemperatureValue : {
        type : Number,
        required : true
    },
    createDate : {
        type : Date,
        required : true,
        default: Date.now()
    }    
});

RoomTemperatureSchema.options.toJSON = {
    transform: function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

module.exports = RoomTemperatureSchema;
