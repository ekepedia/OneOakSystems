/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents room schedule.
 * 
 * @version 1.0
 * @author TCSCODER
 */
'use strict';

var Schema = require('mongoose').Schema,
    ObjectId = Schema.ObjectId;

var ItemSchema = new Schema({
    startTime : {
        type : String,
        required : true
    },
    endTime : {
        type : String,
        required : true
    },
    value : {
        type : Number,
        required : true
    }
});

var RoomScheduleSchema = new Schema({
    roomId : {
        type : ObjectId,
        required : true
    },
    items : [ItemSchema],
    createDate : {
        type : Date,
        required : true,
        default: Date.now()
    }
});

ItemSchema.options.toJSON = {
    transform: function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

RoomScheduleSchema.options.toJSON = {
    transform: function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

module.exports = RoomScheduleSchema;
