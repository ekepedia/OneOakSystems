/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents hosue status.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var Schema = require('mongoose').Schema,
    ObjectId = Schema.ObjectId;

var HouseStatusSchema = new Schema({
    houseId : {
        type : ObjectId,
        required : true,
        ref: 'House'
    },
    timestamp : {
        type : Date,
        required : true,
        default: Date.Now
    },
    predictedNextMonthSavings : {
        type : Number,
        required : true,
        min: 0,
        max: 100
    },
    lastMonthSavings : {
        type : Number,
        required : true,
        min: 0,
        max: 100
    },
    currentTemperature : {
        type : Number,
        required : true
    },
    outsideTemperature : {
        type : Number,
        required : true
    },
    currentHumidity : {
        type : String,
        required : true
    }
});

HouseStatusSchema.options.toJSON = {
    transform: function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

module.exports = HouseStatusSchema;
