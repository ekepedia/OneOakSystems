/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents room alerts.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var Schema = require('mongoose').Schema,
    ObjectId = Schema.ObjectId;

var RoomAlertsSchema = new Schema({
    roomId : {
        type : ObjectId,
        required : true,
        ref : 'Room'
    },
    type : {
        type : String,
        required : true,
        enum : [ 'warning', 'error' ]
    },
    timestamp : {
        type : Date,
        required : true
    },
    details : {
        type : String,
        required : true
    },
    status : {
        type : String,
        required : true,
        enum : [ 'current', 'resolved' ]
    }
});

RoomAlertsSchema.options.toJSON = {
    transform : function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

module.exports = RoomAlertsSchema;
