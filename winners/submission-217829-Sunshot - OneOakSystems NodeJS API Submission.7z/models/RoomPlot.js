/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents room plot.
 * 
 * @version 1.0
 * @author TCSCODER
 */
'use strict';

var Schema = require('mongoose').Schema,
    ObjectId = Schema.ObjectId;

var RoomPlotSchema = new Schema({
    roomId : {
        type : ObjectId,
        required : true
    },
    year : {
        type : String,
        required : true
    },
    month : {
        type : String,
        required : true
    },
    day : {
        type : String,
        required : true
    },
    hour : {
        type : String,
        required : true
    },
    minute : {
        type : String,
        required : true
    },
    second : {
        type : String,
        required : true
    },
    inDST : {
        type : Boolean,
        required : true
    },
    timestamp : {
        type : Date,
        required : true
    },
    light : {
        type : Number,
        required : true,
        min : 0,
        max : 99999999
    },
    tempAnalog : {
        type : Number,
        required : true
    },
    IR : {
        type : Number,
        required : true,
        min : 0,
        max : 3.34
    },
    tempDigital : {
        type : Number,
        required : true
    },
    currentTemp : {
        type : Number,
        required : true
    },
    outsideTemp : {
        type : Number,
        required : true
    },
    desiredTemp : {
        type : Number,
        required : true
    },
    fastHumidity : {
        type : Number,
        required : true
    },
    slowHumidity : {
        type : Number,
        required : true
    }
});

RoomPlotSchema.options.toJSON = {
    transform : function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

module.exports = RoomPlotSchema;
