/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Inits and exports all schemas.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var mongoose = require('mongoose'), config = require('../config/config');

var db = mongoose.createConnection(config.MONGODB_URL, {
    server : {
        poolSize : config.MONGODB_CONNECTION_POOL_SIZE
    }
});

module.exports = {
    User : db.model('User', require('./User'), 'User'),
    House : db.model('House', require('./House'), 'House'),
    HouseUser : db.model('HouseUser', require('./HouseUser'), 'HouseUser'),
    HouseInfo : db.model('HouseInfo', require('./HouseInfo'), 'HouseInfo'),
    HouseStatus : db.model('HouseStatus', require('./HouseStatus'), 'HouseStatus'),
    Room : db.model('Room', require('./Room'), 'Room'),
    RoomSchedule : db.model('RoomSchedule', require('./RoomSchedule'), 'RoomSchedule'),
    RoomTemperature : db.model('RoomTemperature', require('./RoomTemperature'), 'RoomTemperature'),
    RoomPlot : db.model('RoomPlot', require('./RoomPlot'), 'RoomPlot'),
    RoomAlerts : db.model('RoomAlerts', require('./RoomAlerts'), 'RoomAlerts'),
    RoomEnergySavings : db.model('RoomEnergySavings', require('./RoomEnergySavings'), 'RoomEnergySavings'),
    SessionToken : db.model('SessionToken', require('./SessionToken'), 'SessionToken')
};
