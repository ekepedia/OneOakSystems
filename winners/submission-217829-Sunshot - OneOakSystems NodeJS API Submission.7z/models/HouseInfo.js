/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents house info.
 * 
 * @version 1.0
 * @author TCSCODER
 */
'use strict';

var Schema = require('mongoose').Schema,
    ObjectId = Schema.ObjectId;

var RoomTypeSchema = new Schema({
    type : {
        type : String,
        required : true,
        enum : [ 'very small', 'small', 'medium', 'large', 'very large' ]
    },
    quantity : {
        type : Number,
        required : true
    }
});

var UnitTypeSchema = new Schema({
    unityType : {
        type : String,
        required : true,
        enum : [ 'efficiency', '1br', '2br', '3br', '4br' ]
    },
    numberOfUnits : {
        type : Number,
        required : true
    },
    people : {
        type : Number,
        required : true
    }
});

var HouseInfoSchema = new Schema({
    houseId : {
        type : ObjectId,
        required : true,
        ref : 'House'
    },
    type : {
        type : String,
        required : true,
        enum : [ 'homeowner', 'landlord', 'resident' ]
    },
    numberOfResident : {
        type : Number,
        required : false
    },
    residentType : {
        type : String,
        required : false,
        enum : [ 'student', 'family', 'senior', 'shared house' ]
    },
    roomType : {
        type : [ RoomTypeSchema ],
        required : false
    },
    buildingType : {
        type : String,
        required : false,
        enum : [ 'Apartment', 'Dorm', 'Family Home' ]
    },
    unitType : {
        type : [ UnitTypeSchema ],
        required : false
    },
    temperatureUnit : {
        type : String,
        required : false,
        enum : [ 'Celsius', 'Fahrenheit' ]
    }
});

RoomTypeSchema.options.toJSON = {
    transform : function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

UnitTypeSchema.options.toJSON = {
    transform : function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

HouseInfoSchema.options.toJSON = {
    transform : function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

module.exports = HouseInfoSchema;
