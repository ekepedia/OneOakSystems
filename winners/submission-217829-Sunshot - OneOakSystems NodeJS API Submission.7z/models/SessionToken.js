/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents session token.
 * 
 * @version 1.0
 * @author TCSCODER
 */
"use strict";

var Schema = require('mongoose').Schema,
    ObjectId = Schema.ObjectId;

var SessionTokenSchema = new Schema({
    userId: ObjectId,
    token: String,
    expirationDate: {
        type: Date,
        default: Date.now
    }
});

SessionTokenSchema.options.toJSON = {
    transform: function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

// Export the Mongoose model
module.exports = SessionTokenSchema;
