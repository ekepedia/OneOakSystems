/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents room energy savings.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var Schema = require('mongoose').Schema,
    ObjectId = Schema.ObjectId;

var RoomEnergySavingsSchema = new Schema({
    roomId : {
        type : ObjectId,
        required : true,
        ref : 'Room'
    },
    preSystemEnergyExpenditure : {
        type : Number,
        required : true
    },
    postSystemEnergyExpenditure : {
        type : Number,
        required : true
    },
    energySavings : {
        type : Number,
        required : true
    },
    timestamp : {
        type : Date,
        required : true
    }
});

RoomEnergySavingsSchema.options.toJSON = {
    transform : function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

module.exports = RoomEnergySavingsSchema;
