/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents house user.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var Schema = require('mongoose').Schema,
    ObjectId = Schema.ObjectId;

var HouseUserSchema = new Schema({
    houseId : {
        type : ObjectId,
        required : true,
        ref : 'House'
    },
    userId : {
        type : ObjectId,
        required : true,
        ref : 'User'
    },
    role : {
        type : String,
        required : true,
        enum : [ 'admin', 'operator', 'user', 'viewer' ]
    }
});

HouseUserSchema.options.toJSON = {
    transform : function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

module.exports = HouseUserSchema;
