/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents room.
 * 
 * @version 1.0
 * @author TCSCODER
 */
'use strict';

var Schema = require('mongoose').Schema,
    ObjectId = Schema.ObjectId;

var RoomSchema = new Schema({
    houseId : {
        type : ObjectId,
        required : true,
        ref : 'House'
    },
    roomName : {
        type : String,
        required : true
    },
    image : {
        type : String,
        required : false
    },
    description : {
        type : String,
        required : true
    },
    size : {
        type : String,
        required : true,
        enum : [ 'very small', 'small', 'medium', 'large', 'very large' ]
    },
    ventsCount : {
        type : Number,
        required : true
    },
    windowsCount : {
        type : Number,
        required : true
    },
    currentTempreture : {
        type : Number,
        required : false
    }
});

RoomSchema.options.toJSON = {
    transform : function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

module.exports = RoomSchema;
