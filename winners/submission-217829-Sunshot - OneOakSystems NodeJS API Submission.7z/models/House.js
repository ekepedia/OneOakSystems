/*
 * Copyright (C) 2015 TopCoder Inc., All Rights Reserved.
 */
/**
 * Represents house.
 * 
 * @author TCSCODER
 * @version 1.0
 */
'use strict';

var Schema = require('mongoose').Schema,
    ObjectId = Schema.ObjectId;

var HouseSchema = new Schema({
    name : {
        type : String,
        required : true
    },
    image : {
        type : String,
        required : true
    }
});

HouseSchema.options.toJSON = {
    transform : function(doc, ret) {
        delete ret.__v;
        return ret;
    }
};

module.exports = HouseSchema;
